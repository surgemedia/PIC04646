<footer id="footer" class="content-info text-center coal-bg">
  <div class="container">
	<span> &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?></span> 
    <?php dynamic_sidebar('sidebar-footer'); ?>
  </div>
</footer>