<div class="<?php echo $vars['class'] ?> <?php echo $vars['col'] ?>">
    <a href="<?php echo $vars['href']; ?>">
        <img alt="<?php echo $vars['title']; ?>" class="img-reponsive" src="<?php echo $vars['img']; ?>">
        </img>
            <span class="text-center col-xs-12">
                <?php echo $vars['title'] ?>
            </span>
    </a>
    <h2><?php echo $vars['subtitle'] ?></h2>
    <a class='btn' href="<?php echo $vars['href'] ?> " class="btn">Read More</a>
</div>