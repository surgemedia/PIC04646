<section id="contact-us" class="trans-overlay" style="background-image:url(<?php echo $vars['background'] ?>)">
		<div class="container white-font text-center">
		<h1 class="underline">Contact us</h1>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing</p>
		<?php echo do_shortcode("[gravityform id=1 title=false description=false ajax=true tabindex=49]" ); ?>
		</div>
</section>