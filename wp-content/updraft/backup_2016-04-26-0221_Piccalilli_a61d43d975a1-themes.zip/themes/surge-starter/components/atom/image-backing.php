<?php 
	$vars['image'] = $vars[0];
 ?>
<div id="image-backing" style="background-image:url(<?php echo $vars['image']; ?>);">
</div>
