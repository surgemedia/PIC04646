<ul class='list-inline'>
			<li><a href="" class="btn"><span>Shop</span><span>Online</span></a></li>
			<li><a href="" class="btn"><span>Download</span><span>Menu</span></a></li>
			<li><a href="" class="btn"><span>Phone</span><span>Order</span></a></li>
		</ul>