<?php 
// Global DB config
if (!defined('DB_NAME')) {
	define('DB_NAME', 'pic04646');
}
if (!defined('DB_USER')) {
	define('DB_USER', 'pic04646');
}
if (!defined('DB_PASSWORD')) {
	define('DB_PASSWORD', 'pic04646');
}
if (!defined('DB_HOST')) {
	define('DB_HOST', '192.168.0.51');
}

/** Database Charset to use in creating database tables. */
if (!defined('DB_CHARSET')) {
	define('DB_CHARSET', 'utf8');
}

/** The Database Collate type. Don't change this if in doubt. */
if (!defined('DB_COLLATE')) {
	define('DB_COLLATE', '');
}

 ?>